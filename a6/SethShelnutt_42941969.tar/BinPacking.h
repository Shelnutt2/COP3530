/*Name : Seth Shelnutt
UF ID: 42941969
Gator ID: s.shelnutt
Discussion section # : 1085
*/

using namespace std;

class BinPacking{

    public:
        void firstFitPack(int *objectSize, int numberOfObjects, int binCapacity);
        void firstFitPack2(int *objectSize, int numberOfObjects, int binCapacity);
        void bestFitPack(int *objectSize, int numberOfObjects, int binCapacity);
        void bestFitPack2(int *objectSize, int numberOfObjects, int binCapacity);
   
};
