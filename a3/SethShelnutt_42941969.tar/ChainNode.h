using namespace std;

class chainNode
{
   public:
      chainNode(chainNode *a, int b);
      chainNode* next;
      int element;
};
